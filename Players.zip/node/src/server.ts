import dotenv from 'dotenv';
import createApp from './app';
dotenv.config();

const app = createApp();
const port = process.env.PORT;

app.listen(port, () => {
    console.log(`🐱‍👤 Servidor rodando na porta http://localhost:${port}`);
});
