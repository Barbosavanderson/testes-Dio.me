import * as PlayerRepository from "../repositories/player-repository";
import * as httpResponse from "../utils/http-helper";


export const getPlayerService = async () =>  {
   const data =  await PlayerRepository.findAllPlayers();
   let response = null;
   
   if(data){
    response = await httpResponse.ok (data);
   }else{
    response = await httpResponse.noContent();
   }
    return response;
};



export const getPlayerByIdService = async (id: number) =>{
    //solicitar no Repositoris.
    const data = await PlayerRepository.findAllPlayersById(id);
    let response = null;
    
    if(data){
        response = httpResponse.ok(data);
       }else{
        response = httpResponse.noContent();
       }
        return response;
};