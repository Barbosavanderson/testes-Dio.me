export interface playerModel{
    id: number;
    Name: string;
    Club: string;
    Nationality: string;
    Position: string;
    Statistics: {
        overall: number;
        pace: number;
        passing: number;
        dribbling: number;
        defending: number;
        physical: number;
    };
}