export interface HttpResponse {
    statuscode: number;
    body: any;
}