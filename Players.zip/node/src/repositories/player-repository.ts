import { playerModel } from "../Models/player-model";

const database: playerModel[] = [
    {
        id: 1,
        Name: "Messi",
        Club: "PSG",
        Nationality: "Argentino",
        Position: "Forward",
        Statistics:{
            overall: 93,
            pace: 85,
            passing: 94,
            dribbling: 95,
            defending: 10,
            physical: 65,
        },
    },
{
        id: 2,
        Name: "Lautaro Martínez",
        Club: "Inter Milan",
        Nationality: "Argentino",
        Position: "Forward",
        Statistics: {
            overall: 84,
            pace: 81,
            passing: 69,
            dribbling: 86,
            defending: 50,
            physical: 81
        }
    },
    {
        id: 3,
        Name: "Joshua Kimmich",
        Club: "Bayern Munich",
        Nationality: "Alemão",
        Position: "Midfielder",
        Statistics: {
            overall: 89,
            pace: 70,
            passing: 86,
            dribbling: 82,
            defending: 84,
            physical: 79
        }
    },
    {
        id: 4,
       Name: "Kylian Mbappé",
        Club: "PSG",
        Nationality: "Francês",
        Position: "Forward",
        Statistics: {
            overall: 92,
            pace: 96,
            passing: 80,
            dribbling: 92,
            defending: 39,
            physical: 76
        }
    },
    {
        id: 5,
        Name: "Cristiano Ronaldo",
        Club: "Al Nassr",
        Nationality: "Português",
        Position: "Forward",
        Statistics: {
            overall: 91,
            pace: 87,
            passing: 82,
            dribbling: 88,
            defending: 35,
            physical: 77
        }
    },
    
];


export const findAllPlayers= async ():Promise<playerModel[]>  =>{
    return database;
};

export const findAllPlayersById = async (id:number): Promise<playerModel| undefined> =>{
    return database.find((player) => player.id === id);
}