import { HttpResponse } from "../Models/http-presponse-model";


export const ok =  async (data:any): Promise<HttpResponse> => {
    return{
        statuscode: 200,
        body: data
    };
};

export const noContent = async (): Promise<HttpResponse> =>{
    return{
        statuscode: 204,
        body: null,
    }
}