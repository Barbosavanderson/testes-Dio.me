import { Request, Response } from "express";
import * as Service from "../services/players-service";


export const getPlayer = async (req: Request, res: Response) => {
    const httpResponse = await Service.getPlayerService();   
    res.status(httpResponse.statuscode).json(httpResponse.body);
};

export const getPlayerById = async(req: Request, res: Response) => {
  const id = parseInt(req.params.id)
  const httpResponse = await Service.getPlayerByIdService(id);
  res.status(httpResponse.statuscode).json(httpResponse.body);
  
};

